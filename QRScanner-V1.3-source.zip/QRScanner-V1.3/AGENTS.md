# 扫码器项目约定

## 版本与交付（用户明确要求）

- 应用版本唯一来源为项目根目录的 `version.properties`，包含 versionName 和 Android versionCode。
- 今后每完成一轮用户要求的项目修改，交付版本增加 0.1，versionCode 同时增加 1。
- 例如 1.1 → 1.2 → 1.3……1.9 → 2.0；按一位小数的数值递增，避免浮点误差。
- 同一轮修改中的文件保存、编译、检查和修复算一次交付，不要为重复构建再次加版本；纯问答或只读检查不加版本。
- 修改 `version.properties` 后，Gradle 包版本、启动页和关于页通过生成的 `app_version_name` 资源同步更新，不再硬编码版本。
- 源码 ZIP 命名为 `QRScanner-V<版本号>-source.zip`，调试 APK 命名为 `扫码器-V<版本号>-debug.apk`，文件名必须匹配实际内容版本。
- 源码 ZIP 必须包含 `version.properties`、本文件、README、Gradle Wrapper、构建配置及全部 app 源码资源；不打包 build、.gradle、.idea、本机 local.properties 或签名私钥。
- 构建后使用 `python scripts/package_release.py --output-dir <交付目录>` 生成版本匹配的 APK、源码 ZIP 和说明；脚本会验证 APK 元数据，并且不会自行增加版本号。
- README 的当前版本说明也需同步更新；历史版本归档保持原来的版本号。

## 构建

- 在现有项目上修改，保留扫码、权限与相机生命周期实现，不重新创建项目。
- 本机 PowerShell 构建使用 Android Studio 自带 JBR 25：

```powershell
$env:JAVA_HOME = 'C:\Program Files\Android\Android Studio\jbr'
.\gradlew.bat :app:assembleDebug --console=plain
```

- 交付前确认构建成功、APK 元数据版本正确，且 UI 版本与源码 ZIP 命名一致；如无法验证要明确说明。
