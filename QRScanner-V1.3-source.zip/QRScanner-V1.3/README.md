# 扫码器 V1.3

原生 Android 二维码扫描应用。包名 `com.a380fly.qrscanner`，作者 A380fly。
在原有 Android Studio 项目中开发，使用 Kotlin、Jetpack Compose、Material 3、CameraX 和 ML Kit。

## 功能

- 启动页显示「扫码器 V1.3」与「By A380fly」。
- 支持系统控制中心/快捷设置中的「扫码器」磁贴，点击后收起面板并直接开始新一轮扫码；应用菜单提供「添加到控制中心」入口。
- 图标采用蓝底白色「四角扫描框 + QR」矢量设计；桌面、单色主题图标及应用内图形保持一致。
- 实时相机预览，优先后摄，无后摄时尝试前摄；仅识别二维码。
- 识别成功后锁定结果并暂停识别，点击「清除」开始下一次扫描；预览仍保留。
- 结果支持复制和长按选择，保留完整文本，不自动访问二维码中的网址。
- 首次申请相机权限；拒绝后提供说明、重新授权和应用设置入口。
- 进入后台随 Activity 生命周期暂停相机；恢复前台时检查权限并恢复预览。
- 使用原生 Material 3 标题栏、浅色圆角卡片和标准按钮；关于页使用类似系统设置的分组列表。
- 跟随系统浅色/深色主题；Android 12 及以上默认跟随系统动态色，旧系统使用蓝色主题。提供关于页和 GitHub 入口。
- 扫描结果只存于 ViewModel 内存，旋转屏幕后保留；不写入应用文件或历史记录。

ML Kit 使用随 APK 打包的模型，无需在首次扫码时下载模型；设备无需 Google Play 服务即可识别。
没有增加历史记录、广告、相册读取、网络请求客户端或导航框架。
ML Kit 自身的传递依赖可能在合并 Manifest 中声明网络权限；内置模型的识别在设备上执行。

## 版本约定

当前版本为 **1.3**，Android `versionCode=4`。版本统一配置在项目根目录 `version.properties`；Gradle 包版本、启动页和关于页会同步使用该版本。
按用户要求，此后每完成一轮项目修改，版本号增加 0.1、versionCode 增加 1，下一版为 1.4（1.9 之后为 2.0）。同一轮中的修复与重复构建不再次加版本。
交付文件名称同步为 `扫码器-V1.3-debug.apk` 和 `QRScanner-V1.3-source.zip`，后续使用对应的新版本号。规则同时记录在 `AGENTS.md`，源码包包含这两个配置文件。
完成构建后可运行 `python scripts/package_release.py --output-dir <交付目录>`，打包脚本会从版本配置生成文件名，并检查 APK 版本、文件复制和 ZIP 完整性，避免将旧版本 APK 误标成新版本。打包脚本本身不会再次递增版本。

## 添加控制中心快捷方式

1. 覆盖安装 V1.3 并至少打开应用一次。
2. 点击右上角菜单 →「添加到控制中心」。Android 13 及以上会请求系统显示添加确认；请在系统提示中确认。
3. 如果没有系统弹窗，或你的系统不支持应用内请求，手动下拉控制中心，点击「编辑」或「＋」，找到「扫码器」并添加、保存。不同厂商的入口名称和页面位置可能不同。
4. 点击控制中心中的「扫码器」即可收起面板、返回扫描页面并清除上一轮结果；冷启动从该入口进入会跳过应用启动页。
5. 锁屏状态下会先请求解锁；相机权限仍由应用正常申请。磁贴本身不在后台启动相机，不需要 root、无障碍或其他运行时权限。

使用的是 Android 原生 `TileService`；系统控制中心的样式由手机系统决定。Android 14 及以上使用 `PendingIntent` 启动 Activity，以兼容新系统的磁贴启动要求。
实现依据：[Android 快捷设置磁贴指南](https://developer.android.com/develop/ui/views/quicksettings-tiles)、[StatusBarManager 添加磁贴接口](https://developer.android.com/reference/android/app/StatusBarManager)。

## Android Studio 运行

1. 使用 **Open** 打开 `C:\Users\wj134\AndroidStudioProjects\QRScanner`。
2. 在 **Settings → Build, Execution, Deployment → Build Tools → Gradle** 中，选择 Android Studio 自带 JBR 25 作为 Gradle JDK。
3. SDK Manager 需安装 Android API 37 平台和 Android SDK Build-Tools 36.0.0（本机已具备）。项目通过 `local.properties` 定位本机 SDK。
4. 等待 Gradle Sync，连接启用了 USB 调试的 Android 8.0/API 26 或更新设备，选择 `app` 并点击 Run。
5. 首次启动允许相机权限，将清晰的二维码置于取景区域内。二维码识别会分析整个相机帧，取景角框用于辅助对准。

项目保留原配置：Gradle Wrapper 9.5.0、Android Gradle Plugin 9.3.3、Kotlin/Compose Compiler 2.2.10、Compose BOM 2026.02.01。
新增 CameraX 1.5.3、ML Kit Barcode Scanning 17.3.0，以及用于状态管理和生命周期的 AndroidX Compose 集成。

## Windows 构建和 APK

在项目目录打开 PowerShell：

```powershell
$env:JAVA_HOME = 'C:\Program Files\Android\Android Studio\jbr'
.\gradlew.bat :app:assembleDebug
```

可安装的 Debug APK：

```text
app\build\outputs\apk\debug\app-debug.apk
```

安装到已连接设备：

```powershell
& 'C:\Users\wj134\AppData\Local\Android\Sdk\platform-tools\adb.exe' install -r .\app\build\outputs\apk\debug\app-debug.apk
```

该 APK 使用本机 Android Debug 密钥签名，适合开发和自用测试。若已有同包名、不同签名的应用，更新安装会被系统拒绝；请核对签名和数据保留需求后再处理。
正式发布时，在 Android Studio 选择 **Build → Generate Signed App Bundle or APK → APK**，创建或选择自己的 keystore，并构建 `release`；妥善保管签名密钥。
仅执行 `assembleRelease` 而未配置签名时会生成未签名的产物。

## 仓库地址占位配置

修改 `app/src/main/res/values/strings.xml`：

```xml
<string name="github_url" translatable="false">https://github.com/your-username/QRScanner</string>
```

将占位值替换成真实 GitHub 仓库的 HTTPS 地址并重新编译。仍为占位值时，入口提示「项目仓库地址尚未发布」，不会打开虚假仓库。

## 结构

```text
app/src/main/java/com/a380fly/qrscanner/
  MainActivity.kt                 Activity 与 Compose 入口
  quicksettings/ScannerTileService.kt  控制中心快捷磁贴与前台启动
  quicksettings/QuickSettingsTileController.kt  系统添加请求与兼容回退
  permission/CameraPermission.kt  权限请求、设置入口、前台复查
  scanner/ScannerCameraPreview.kt CameraX 绑定与 ML Kit 分析、资源释放
  state/ScanState.kt              首次结果锁定、清除、旧回调过滤
  state/ScannerViewModel.kt       旋转时保留会话内状态
  ui/ScannerApp.kt                启动/扫描/关于页面与复制、仓库操作
  ui/QuickSettingsTileEntry.kt     添加磁贴的提示与手动添加指引
  ui/ScannerScreen.kt             扫描主界面、权限和异常界面
  ui/StartupScreen.kt             启动页
  ui/AboutScreen.kt               关于页
  ui/ScannerGraphics.kt          轻量 Canvas 图形
  ui/theme/                      系统浅深色 Material 3 主题
```

相机组件每次进入页面仅绑定一组 Preview/ImageAnalysis，使用单线程分析与 `STRATEGY_KEEP_ONLY_LATEST`。
ML Kit 任务完成后关闭 `ImageProxy`；离开页面时仅解绑自己的 use case，关闭执行器，等待在途任务完成后关闭识别器。
通过扫描 session、前后台 epoch 和 disposed 状态过滤迟到结果。

## 验证

2026-10-16 V1.3 已在本机 Windows 环境执行并通过：Debug APK 构建、9 个 JUnit 测试（其中 8 个扫描状态测试）、`lintDebug`（0 错误、14 个依赖版本更新提示），以及 APK 签名验证与 16 KB ZIP 对齐检查。APK 元数据为 versionName=1.3、versionCode=4，界面版本资源为 V1.3；签名与上一版相同，可以覆盖安装。
已检查最终 APK 的合并 Manifest，确认磁贴服务已导出、由系统 BIND_QUICK_SETTINGS_TILE 权限保护，并注册 QS_TILE action；本轮未增加第三方依赖或额外运行时权限。磁贴冷启动、热启动、旋转请求去重和清除旧结果路径已做代码交叉审查。9 个单元测试不等同于控制中心的设备集成测试，添加弹窗及磁贴点击仍需在手机系统上验证。
图标采用蓝底白色「四角扫描框 + QR」。此前已检查 48/72/96/128 像素预览及圆形、圆角方形、单色遮罩，图形无裁切。前景与单色图层位于自适应图标安全区内，应用内使用同一几何的紧凑矢量资源；旧密度 WEBP 图标也已同步替换。
构建中发现的 API 26 导航栏样式兼容错误已使用 v27 资源限定修复。
本次环境没有已连接的真机；现有 Android 模拟器在启动后持续 offline，未进入可运行状态。因此尚未完成设备上的扫码、权限交互和相机前后台恢复验证，不将静态检查视为硬件运行验证。

```powershell
$env:JAVA_HOME = 'C:\Program Files\Android\Android Studio\jbr'
.\gradlew.bat :app:assembleDebug :app:testDebugUnitTest :app:lintDebug
```

`ScanStateTest` 覆盖结果锁定、重复扫码、清除和迟到回调、空内容、Unicode 与空白文本完整性。
硬件验证建议：正常/拒绝/多次拒绝权限、系统设置重新授权、连续扫码与复制、前后台切换、屏幕旋转、相机被占用、长文本二维码、浅深色和大字体。

## 官方实现依据

- [CameraX 图像分析与 ImageProxy 生命周期](https://developer.android.com/media/camera/camerax/analyze)
- [ML Kit 二维码扫描与内置模型](https://developers.google.com/ml-kit/vision/barcode-scanning/android)
- [Android 运行时权限](https://developer.android.com/training/permissions/requesting)
