package com.a380fly.qrscanner.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.a380fly.qrscanner.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(onBack: () -> Unit, onGitHub: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("关于扫码器") },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.semantics { contentDescription = "返回扫描" },
                    ) {
                        LineIcon(SmallIcon.Back, colors.onSurface, Modifier.size(24.dp))
                    }
                },
            )
        },
    ) { padding ->
        Box(
            Modifier.fillMaxSize().padding(padding).consumeWindowInsets(padding),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                Modifier.widthIn(max = 600.dp).fillMaxWidth()
                    .verticalScroll(rememberScrollState()).padding(vertical = 8.dp),
            ) {
                AboutSectionTitle("应用信息")
                ListItem(
                    headlineContent = { Text(stringResource(R.string.app_name)) },
                    supportingContent = { Text(stringResource(R.string.app_version_name)) },
                    leadingContent = { QrMark(Modifier.size(40.dp), colors.primary) },
                )
                ListItem(
                    headlineContent = { Text("开发者") },
                    supportingContent = { Text(stringResource(R.string.app_author)) },
                )
                ListItem(
                    headlineContent = { Text("在 GitHub 上打开") },
                    supportingContent = { Text("查看项目仓库") },
                    trailingContent = {
                        LineIcon(SmallIcon.External, colors.onSurfaceVariant, Modifier.size(24.dp))
                    },
                    modifier = Modifier.clickable(role = Role.Button, onClick = onGitHub),
                )
                HorizontalDivider(Modifier.padding(horizontal = 16.dp, vertical = 16.dp))
                AboutSectionTitle("使用提示")
                ListItem(
                    headlineContent = { Text("继续扫描") },
                    supportingContent = {
                        Text("识别成功后会暂停识别，点击「清除」即可扫描下一个二维码。")
                    },
                )
                ListItem(
                    headlineContent = { Text("复制扫描结果") },
                    supportingContent = {
                        Text("长按结果可以选择文字，也可以点击「复制」保存到系统剪贴板。")
                    },
                )
                ListItem(
                    headlineContent = { Text("本机识别") },
                    supportingContent = {
                        Text("二维码在设备上识别，扫描结果仅保留在当前应用会话中。")
                    },
                )
            }
        }
    }
}

@Composable
private fun AboutSectionTitle(text: String) {
    Text(
        text,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp),
        color = MaterialTheme.colorScheme.primary,
        style = MaterialTheme.typography.titleSmall,
    )
}
