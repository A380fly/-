package com.a380fly.qrscanner.ui

import androidx.compose.foundation.Canvas
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import com.a380fly.qrscanner.R

/** Small vector-like graphics keep the APK free of an entire icon font/library. */
@Composable
fun QrMark(modifier: Modifier = Modifier, color: Color) {
    Icon(
        painter = painterResource(R.drawable.ic_scanner_mark),
        contentDescription = "QR 扫描图标",
        modifier = modifier,
        tint = color,
    )
}

@Composable
fun ScanCorners(modifier: Modifier = Modifier, color: Color) {
    Canvas(modifier) {
        val inset = size.minDimension * 0.15f
        val left = (size.width - size.minDimension) / 2 + inset
        val top = (size.height - size.minDimension) / 2 + inset
        val right = size.width - left
        val bottom = size.height - top
        val arm = 24f * density
        val path = Path().apply {
            moveTo(left, top + arm); lineTo(left, top); lineTo(left + arm, top)
            moveTo(right - arm, top); lineTo(right, top); lineTo(right, top + arm)
            moveTo(right, bottom - arm); lineTo(right, bottom); lineTo(right - arm, bottom)
            moveTo(left + arm, bottom); lineTo(left, bottom); lineTo(left, bottom - arm)
        }
        drawPath(path, color, style = Stroke(3f * density, cap = StrokeCap.Round))
    }
}

enum class SmallIcon { Menu, Back, Copy, Clear, External }

@Composable
fun LineIcon(icon: SmallIcon, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val unit = size.minDimension / 24
        fun line(x1: Float, y1: Float, x2: Float, y2: Float) = drawLine(
            color, Offset(x1 * unit, y1 * unit), Offset(x2 * unit, y2 * unit),
            strokeWidth = 1.8f * unit, cap = StrokeCap.Round,
        )
        when (icon) {
            SmallIcon.Menu -> listOf(5f, 12f, 19f).forEach {
                drawCircle(color, 1.6f * unit, Offset(12f * unit, it * unit))
            }
            SmallIcon.Back -> {
                line(19f, 12f, 5f, 12f); line(5f, 12f, 11f, 6f); line(5f, 12f, 11f, 18f)
            }
            SmallIcon.Copy -> {
                drawRoundRect(color, Offset(8 * unit, 7 * unit), Size(12 * unit, 14 * unit),
                    CornerRadius(2 * unit), style = Stroke(1.8f * unit))
                line(15f, 3f, 4f, 3f); line(4f, 3f, 4f, 16f)
            }
            SmallIcon.Clear -> {
                line(5f, 7f, 19f, 7f); line(9f, 4f, 15f, 4f)
                line(7f, 7f, 8f, 21f); line(8f, 21f, 16f, 21f); line(16f, 21f, 17f, 7f)
                line(10f, 11f, 10.5f, 17f); line(14f, 11f, 13.5f, 17f)
            }
            SmallIcon.External -> {
                line(14f, 4f, 20f, 4f); line(20f, 4f, 20f, 10f); line(20f, 4f, 11f, 13f)
                line(10f, 5f, 4f, 5f); line(4f, 5f, 4f, 20f)
                line(4f, 20f, 19f, 20f); line(19f, 20f, 19f, 14f)
            }
        }
    }
}
