package com.a380fly.qrscanner.quicksettings

import android.app.Activity
import android.app.StatusBarManager
import android.content.ComponentName
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.annotation.RequiresApi
import com.a380fly.qrscanner.R
import java.util.concurrent.Executor
import java.util.concurrent.atomic.AtomicBoolean

enum class TileAddResult {
    ADDED,
    ALREADY_ADDED,
    NOT_ADDED,
    MANUAL,
    FAILED,
}

object QuickSettingsTileController {
    /** Must be triggered by a user action while [activity] is in the foreground. */
    fun requestAddTile(activity: Activity, onResult: (TileAddResult) -> Unit) {
        val mainHandler = Handler(Looper.getMainLooper())
        val mainExecutor = Executor { command -> mainHandler.post(command) }
        val delivered = AtomicBoolean(false)

        fun deliver(result: TileAddResult) {
            if (delivered.compareAndSet(false, true)) {
                mainExecutor.execute { onResult(result) }
            }
        }

        val request = Runnable {
            if (activity.isFinishing || activity.isDestroyed) {
                deliver(TileAddResult.FAILED)
                return@Runnable
            }
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                deliver(TileAddResult.MANUAL)
                return@Runnable
            }
            try {
                val manager = activity.getSystemService(StatusBarManager::class.java)
                if (manager == null) {
                    deliver(TileAddResult.MANUAL)
                    return@Runnable
                }
                manager.requestAddTileService(
                    ComponentName(activity, ScannerTileService::class.java),
                    activity.getString(R.string.app_name),
                    Icon.createWithResource(activity, R.drawable.ic_qs_scanner),
                    mainExecutor,
                ) { result -> deliver(mapResult(result)) }
            } catch (error: RuntimeException) {
                // Includes unsupported OEM implementations and security/user restrictions.
                Log.w(TAG, "Quick Settings placement unavailable; use manual editing", error)
                deliver(TileAddResult.MANUAL)
            } catch (error: LinkageError) {
                // An OEM may advertise an API level without implementing its placement API.
                Log.w(TAG, "Quick Settings placement API is unavailable", error)
                deliver(TileAddResult.MANUAL)
            }
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            request.run()
        } else {
            mainHandler.post(request)
        }
    }

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    internal fun mapResult(result: Int): TileAddResult = when (result) {
        StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ADDED -> TileAddResult.ADDED
        StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ALREADY_ADDED -> TileAddResult.ALREADY_ADDED
        StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_NOT_ADDED -> TileAddResult.NOT_ADDED
        StatusBarManager.TILE_ADD_REQUEST_ERROR_NO_STATUS_BAR_SERVICE -> TileAddResult.MANUAL
        else -> TileAddResult.FAILED
    }

    private const val TAG = "QuickSettingsTile"
}
