package com.a380fly.qrscanner.ui.theme

import androidx.compose.ui.graphics.Color

internal val BlueLight = Color(0xFF005AC1)
internal val BlueDark = Color(0xFFADC6FF)
internal val InkLight = Color(0xFF1A1B20)
internal val InkDark = Color(0xFFE3E2E9)
internal val BackgroundLight = Color(0xFFFAF8FF)
internal val BackgroundDark = Color(0xFF121318)
