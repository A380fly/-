package com.a380fly.qrscanner.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.widget.Toast
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.a380fly.qrscanner.quicksettings.QuickSettingsTileController
import com.a380fly.qrscanner.quicksettings.TileAddResult
import java.util.concurrent.atomic.AtomicBoolean

data class QuickSettingsTileEntry(
    val inProgress: Boolean,
    val request: () -> Unit,
)

@Composable
fun rememberQuickSettingsTileEntry(): QuickSettingsTileEntry {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val active = remember(context) { AtomicBoolean(true) }
    var inProgress by remember(context) { mutableStateOf(false) }
    var manualGuidance by remember(context) { mutableStateOf(false) }

    DisposableEffect(active) {
        active.set(true)
        onDispose { active.set(false) }
    }

    val request: () -> Unit = remember(context, activity, active) {
        {
            if (active.get() && !inProgress) {
                if (activity == null || activity.isFinishing || activity.isDestroyed) {
                    manualGuidance = true
                } else {
                    inProgress = true
                    QuickSettingsTileController.requestAddTile(activity) { result ->
                        // The platform may reply after navigation or an Activity recreation.
                        if (active.get() && !activity.isFinishing && !activity.isDestroyed) {
                            inProgress = false
                            when (result) {
                                TileAddResult.ADDED -> Toast.makeText(
                                    context.applicationContext,
                                    "已将「扫码器」添加到控制中心",
                                    Toast.LENGTH_SHORT,
                                ).show()

                                TileAddResult.ALREADY_ADDED -> Toast.makeText(
                                    context.applicationContext,
                                    "控制中心中已添加「扫码器」",
                                    Toast.LENGTH_SHORT,
                                ).show()

                                TileAddResult.NOT_ADDED -> Toast.makeText(
                                    context.applicationContext,
                                    "未添加快捷方式。也可下拉控制中心，在编辑 / ＋中手动添加「扫码器」",
                                    Toast.LENGTH_LONG,
                                ).show()

                                TileAddResult.MANUAL, TileAddResult.FAILED -> {
                                    manualGuidance = true
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (manualGuidance) {
        AlertDialog(
            onDismissRequest = { manualGuidance = false },
            title = { Text("手动添加到控制中心") },
            text = {
                Text(
                    "此设备需要在控制中心中手动添加快捷方式。\n\n" +
                        "下拉控制中心 → 编辑 / ＋ → 找到「扫码器」→ 添加并保存。\n\n" +
                        "不同系统的入口名称或位置可能不同。添加后，点击「扫码器」即可打开扫描页面。",
                )
            },
            confirmButton = {
                TextButton(onClick = { manualGuidance = false }) {
                    Text("知道了")
                }
            },
        )
    }

    return QuickSettingsTileEntry(inProgress = inProgress, request = request)
}

private fun Context.findActivity(): Activity? {
    var current = this
    while (current is ContextWrapper) {
        if (current is Activity) return current
        val base = current.baseContext
        if (base === current) return null
        current = base
    }
    return current as? Activity
}
