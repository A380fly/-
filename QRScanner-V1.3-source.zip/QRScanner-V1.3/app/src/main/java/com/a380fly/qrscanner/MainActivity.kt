package com.a380fly.qrscanner

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.a380fly.qrscanner.quicksettings.ScannerTileService.Companion.ACTION_SCAN_FROM_TILE
import com.a380fly.qrscanner.quicksettings.ScannerTileService.Companion.EXTRA_TILE_REQUEST_ID
import com.a380fly.qrscanner.ui.ScannerApp
import com.a380fly.qrscanner.ui.theme.QrScannerTheme
import java.util.UUID

class MainActivity : ComponentActivity() {
    private var tileScanRequest by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        readTileScanRequest(intent)
        enableEdgeToEdge()
        setContent {
            QrScannerTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ScannerApp(tileScanRequest = tileScanRequest)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readTileScanRequest(intent)
    }

    private fun readTileScanRequest(launchIntent: Intent?) {
        if (launchIntent?.action != ACTION_SCAN_FROM_TILE) return
        val requestId = launchIntent.getStringExtra(EXTRA_TILE_REQUEST_ID)
            ?: UUID.randomUUID().toString().also {
                // Preserve the same request when this Activity is recreated after rotation.
                launchIntent.putExtra(EXTRA_TILE_REQUEST_ID, it)
            }
        tileScanRequest = requestId
    }
}
