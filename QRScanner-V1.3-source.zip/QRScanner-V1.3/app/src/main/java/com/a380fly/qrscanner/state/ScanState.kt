package com.a380fly.qrscanner.state

/** Keeps the first result until cleared, and rejects callbacks from an old scan session. */
data class ScanState(
    val result: String? = null,
    val session: Int = 0,
) {
    fun accept(value: String, callbackSession: Int): ScanState =
        if (callbackSession == session && result == null && value.isNotEmpty()) {
            copy(result = value)
        } else {
            this
        }

    fun clear(): ScanState = ScanState(session = session + 1)
}
