package com.a380fly.qrscanner.quicksettings

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.util.Log
import android.widget.Toast
import com.a380fly.qrscanner.MainActivity
import com.a380fly.qrscanner.R
import java.util.UUID

/** A momentary scan action; camera and recognition only run in the foreground activity. */
class ScannerTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        qsTile?.apply {
            label = getString(R.string.app_name)
            contentDescription = "打开扫码器，扫描二维码"
            icon = Icon.createWithResource(this@ScannerTileService, R.drawable.ic_qs_scanner)
            state = Tile.STATE_INACTIVE
            updateTile()
        }
    }

    override fun onClick() {
        super.onClick()
        if (isLocked) {
            // Never open the camera or expose a previous scan result before the user unlocks.
            unlockAndRun { openScanner() }
        } else {
            openScanner()
        }
    }

    private fun openScanner() {
        val scanIntent = Intent(this, MainActivity::class.java).apply {
            action = ACTION_SCAN_FROM_TILE
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_TILE_REQUEST_ID, UUID.randomUUID().toString())
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val pendingIntent = PendingIntent.getActivity(
                    this,
                    0,
                    scanIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                )
                startActivityAndCollapse(pendingIntent)
            } else {
                openScannerBeforeAndroid14(scanIntent)
            }
        } catch (error: RuntimeException) {
            // Some system UIs may reject an activity launch; keep the tile service safe.
            Log.w(TAG, "Could not open the scanner from Quick Settings", error)
            Toast.makeText(this, "无法打开扫码器，请从桌面打开应用", Toast.LENGTH_LONG).show()
        }
    }

    // API 26–33 do not have the PendingIntent overload. API 34+ always uses it above.
    @SuppressLint("StartActivityAndCollapseDeprecated")
    @Suppress("DEPRECATION")
    private fun openScannerBeforeAndroid14(scanIntent: Intent) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startActivityAndCollapse(scanIntent)
        }
    }

    companion object {
        const val ACTION_SCAN_FROM_TILE = "com.a380fly.qrscanner.action.SCAN_FROM_TILE"
        const val EXTRA_TILE_REQUEST_ID = "com.a380fly.qrscanner.extra.TILE_REQUEST_ID"
        private const val TAG = "ScannerTileService"
    }
}
