package com.a380fly.qrscanner.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.a380fly.qrscanner.R

@Composable
fun StartupScreen() {
    val colors = MaterialTheme.colorScheme
    Box(Modifier.fillMaxSize().safeDrawingPadding().padding(24.dp)) {
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            QrMark(Modifier.size(64.dp), colors.primary)
            Spacer(Modifier.height(24.dp))
            Text(
                "${stringResource(R.string.app_name)} ${stringResource(R.string.app_version_name)}",
                style = MaterialTheme.typography.headlineSmall,
            )
        }
        Text(
            stringResource(R.string.app_author),
            color = colors.onSurfaceVariant,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp),
        )
    }
}
