package com.a380fly.qrscanner.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.unit.sp

private val MaterialTypography = Typography()

// Keep Material 3's native font, sizes and weights. Avoid added tracking for Chinese.
val Typography = MaterialTypography.copy(
    titleMedium = MaterialTypography.titleMedium.copy(letterSpacing = 0.sp),
    titleSmall = MaterialTypography.titleSmall.copy(letterSpacing = 0.sp),
    bodyLarge = MaterialTypography.bodyLarge.copy(letterSpacing = 0.sp),
    bodyMedium = MaterialTypography.bodyMedium.copy(letterSpacing = 0.sp),
    bodySmall = MaterialTypography.bodySmall.copy(letterSpacing = 0.sp),
    labelLarge = MaterialTypography.labelLarge.copy(letterSpacing = 0.sp),
    labelMedium = MaterialTypography.labelMedium.copy(letterSpacing = 0.sp),
    labelSmall = MaterialTypography.labelSmall.copy(letterSpacing = 0.sp),
)
