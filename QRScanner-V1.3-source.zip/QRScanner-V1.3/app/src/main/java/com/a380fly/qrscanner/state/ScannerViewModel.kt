package com.a380fly.qrscanner.state

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

class ScannerViewModel : ViewModel() {
    // In-memory only: survives activity rotation without writing QR contents to storage.
    var state by mutableStateOf(ScanState())
        private set

    fun onQrCode(value: String, session: Int) {
        state = state.accept(value, session)
    }

    fun clearResult() {
        state = state.clear()
    }
}
