package com.a380fly.qrscanner.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.a380fly.qrscanner.permission.CameraPermission
import com.a380fly.qrscanner.scanner.ScannerCameraPreview
import com.a380fly.qrscanner.state.ScanState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScannerScreen(
    state: ScanState,
    permission: CameraPermission,
    onQrCode: (String, Int) -> Unit,
    onClear: () -> Unit,
    onCopy: () -> Unit,
    onAbout: () -> Unit,
    onGitHub: () -> Unit,
    onAddQuickSettingsTile: () -> Unit,
    addingQuickSettingsTile: Boolean,
) {
    var menuExpanded by remember { mutableStateOf(false) }
    var cameraAttempt by remember { mutableIntStateOf(0) }
    var cameraReady by remember(permission.granted, cameraAttempt) { mutableStateOf(false) }
    var cameraError by remember(permission.granted, cameraAttempt) { mutableStateOf<String?>(null) }
    val colors = MaterialTheme.colorScheme
    val status = when {
        !permission.granted -> "等待相机授权"
        cameraError != null -> "相机暂不可用"
        state.result != null -> "识别完成"
        !cameraReady -> "正在启动相机"
        else -> "正在扫描"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("扫码器", style = MaterialTheme.typography.headlineSmall) },
                actions = {
                    Box {
                        IconButton(
                            onClick = { menuExpanded = true },
                            modifier = Modifier.semantics { contentDescription = "更多选项" },
                        ) { LineIcon(SmallIcon.Menu, colors.onSurface, Modifier.size(24.dp)) }
                        DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                            DropdownMenuItem(
                                text = { Text("添加到控制中心") },
                                enabled = !addingQuickSettingsTile,
                                onClick = {
                                    menuExpanded = false
                                    onAddQuickSettingsTile()
                                },
                            )
                            DropdownMenuItem(text = { Text("关于扫码器") }, onClick = {
                                menuExpanded = false
                                onAbout()
                            })
                            DropdownMenuItem(text = { Text("在 GitHub 上打开") }, onClick = {
                                menuExpanded = false
                                onGitHub()
                            })
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.surface),
            )
        },
    ) { padding ->
        BoxWithConstraints(
            Modifier.fillMaxSize().padding(padding).consumeWindowInsets(padding),
            contentAlignment = Alignment.TopCenter,
        ) {
            val previewHeight = (maxHeight * 0.38f).coerceIn(220.dp, 330.dp)
            Column(
                Modifier.widthIn(max = 600.dp).fillMaxWidth().verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp).padding(top = 16.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.extraLarge,
                    colors = CardDefaults.cardColors(containerColor = colors.surfaceContainerLow),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                        ) {
                            Surface(shape = CircleShape, color = colors.secondaryContainer) {
                                QrMark(Modifier.padding(12.dp).size(24.dp), colors.onSecondaryContainer)
                            }
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("扫描二维码", style = MaterialTheme.typography.titleMedium)
                                Text(status, color = colors.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                        Box(
                            Modifier.fillMaxWidth().height(previewHeight).clip(MaterialTheme.shapes.large)
                                .background(if (permission.granted && cameraError == null) Color.Black else colors.surfaceContainerLow),
                        ) {
                            when {
                                !permission.granted -> PermissionPanel(permission)
                                cameraError != null -> CameraMessage(
                                    title = "暂时无法使用相机",
                                    description = cameraError.orEmpty(),
                                    action = "重试",
                                    onAction = { cameraAttempt++ },
                                )
                                else -> {
                                    key(cameraAttempt) {
                                        ScannerCameraPreview(
                                            modifier = Modifier.fillMaxSize(),
                                            scanningEnabled = state.result == null,
                                            scanSession = state.session,
                                            onQrCode = onQrCode,
                                            onReady = { cameraReady = true },
                                            onError = { cameraError = it },
                                        )
                                    }
                                    ScanCorners(Modifier.fillMaxSize(), Color.White)
                                    if (!cameraReady) {
                                        CircularProgressIndicator(
                                            Modifier.align(Alignment.Center).size(32.dp),
                                            color = Color.White,
                                        )
                                    }
                                    Surface(
                                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp),
                                        shape = CircleShape,
                                        color = Color.Black.copy(alpha = 0.52f),
                                        contentColor = Color.White,
                                    ) {
                                        Text(
                                            if (state.result != null) "已暂停识别 · 清除后继续" else "自动识别二维码",
                                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                                            style = MaterialTheme.typography.labelMedium,
                                        )
                                    }
                                }
                            }
                        }
                        if (permission.granted && cameraError == null) {
                            Text(
                                "将二维码放入取景区域，即可自动识别。",
                                style = MaterialTheme.typography.bodyMedium,
                                color = colors.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 8.dp),
                            )
                        }
                    }
                }

                ResultCard(state.result, onCopy, onClear)
            }
        }
    }
}

@Composable
private fun ResultCard(result: String?, onCopy: () -> Unit, onClear: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(containerColor = colors.surfaceContainerLow),
    ) {
        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(
                "扫描结果",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.semantics { heading() },
            )
            if (result == null) {
                Text(
                    "识别到的二维码内容会显示在这里。",
                    color = colors.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 64.dp),
                )
            } else {
                SelectionContainer {
                    Text(
                        result,
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 64.dp, max = 200.dp)
                            .verticalScroll(rememberScrollState()).semantics { liveRegion = LiveRegionMode.Polite },
                    )
                }
            }
            Text(
                if (result == null) "二维码在设备上识别。" else "点击清除，继续扫描下一个二维码。",
                style = MaterialTheme.typography.bodyMedium,
                color = colors.onSurfaceVariant,
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = onCopy,
                    enabled = result != null,
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                ) {
                    LineIcon(SmallIcon.Copy, LocalContentColor.current, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("复制")
                }
                FilledTonalButton(
                    onClick = onClear,
                    enabled = result != null,
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                ) {
                    LineIcon(SmallIcon.Clear, LocalContentColor.current, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("清除")
                }
            }
        }
    }
}

@Composable
private fun PermissionPanel(permission: CameraPermission) {
    val colors = MaterialTheme.colorScheme
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            "需要相机权限",
            color = colors.onSurface,
            style = MaterialTheme.typography.titleMedium,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            if (permission.permanentlyDenied) "需要相机权限才能识别二维码。可重新授权；若系统未弹出提示，请前往设置开启。"
            else "扫码器需要相机权限来预览画面并识别二维码。请允许使用相机。",
            color = colors.onSurfaceVariant, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = permission.request) { Text(if (permission.requested) "重新授权" else "允许使用相机") }
        if (permission.requested) {
            TextButton(onClick = permission.openSettings) { Text("前往系统设置") }
        }
    }
}

@Composable
private fun CameraMessage(title: String, description: String, action: String, onAction: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(title, color = colors.onSurface, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))
        Text(
            description,
            color = colors.onSurfaceVariant,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = onAction) { Text(action) }
    }
}
