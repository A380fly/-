package com.a380fly.qrscanner.scanner

import android.content.Context
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.CameraState
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/** The caller owns permission requests and increments [scanSession] when clearing a result. */
@Composable
fun ScannerCameraPreview(
    modifier: Modifier = Modifier,
    scanningEnabled: Boolean,
    scanSession: Int,
    onQrCode: (String, Int) -> Unit,
    onReady: () -> Unit,
    onError: (String) -> Unit,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val latestOnQrCode = rememberUpdatedState(onQrCode)
    val latestOnReady = rememberUpdatedState(onReady)
    val latestOnError = rememberUpdatedState(onError)
    val request = remember { AtomicReference(ScanRequest(scanningEnabled, scanSession)) }
    val previewView = remember(context) {
        PreviewView(context).apply {
            // TextureView composes reliably with the rounded frame and Compose overlays.
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
            contentDescription = "二维码相机预览"
        }
    }

    SideEffect { request.set(ScanRequest(scanningEnabled, scanSession)) }

    DisposableEffect(previewView, lifecycleOwner) {
        val controller = ScannerCameraController(
            context = context,
            lifecycleOwner = lifecycleOwner,
            previewView = previewView,
            request = request,
            onQrCode = { value, session -> latestOnQrCode.value(value, session) },
            onReady = { latestOnReady.value() },
            onError = { message -> latestOnError.value(message) },
        )
        controller.start()
        onDispose { controller.close() }
    }

    AndroidView(factory = { previewView }, modifier = modifier)
}

private data class ScanRequest(val enabled: Boolean, val session: Int)

/** One owner per composition: recomposition never binds another camera or creates another scanner. */
private class ScannerCameraController(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val previewView: PreviewView,
    private val request: AtomicReference<ScanRequest>,
    private val onQrCode: (String, Int) -> Unit,
    private val onReady: () -> Unit,
    private val onError: (String) -> Unit,
) {
    private val mainExecutor = ContextCompat.getMainExecutor(context)
    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val disposed = AtomicBoolean(false)
    private val foreground = AtomicBoolean(false)
    private val foregroundEpoch = AtomicInteger(0)
    private val deliveredSession = AtomicReference<Int?>(null)
    private val recognitionFailed = AtomicBoolean(false)
    private val scannerLock = Any()
    private var scanner: BarcodeScanner? = null
    private var frameInFlight = false // Guarded by scannerLock; close waits for this frame.
    private var provider: ProcessCameraProvider? = null
    private var cameraState: LiveData<CameraState>? = null
    private var lastError: String? = null
    private val preview = Preview.Builder().build()
    private val analysis = ImageAnalysis.Builder()
        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
        .setResolutionSelector(
            ResolutionSelector.Builder()
                .setResolutionStrategy(
                    ResolutionStrategy(
                        Size(1280, 720),
                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER,
                    ),
                )
                .build(),
        )
        .build()

    private val lifecycleObserver = LifecycleEventObserver { _, _ ->
        val resumed = lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)
        if (foreground.getAndSet(resumed) != resumed) {
            // A result started before a trip to the background must never reappear on return.
            foregroundEpoch.incrementAndGet()
        }
    }

    private val streamObserver = Observer<PreviewView.StreamState> { state ->
        if (!disposed.get() && state == PreviewView.StreamState.STREAMING) {
            lastError = null
            onReady()
        }
    }

    private val cameraStateObserver = Observer<CameraState> { state ->
        state.error?.let { error ->
            val message = when (error.code) {
                CameraState.ERROR_CAMERA_IN_USE, CameraState.ERROR_MAX_CAMERAS_IN_USE ->
                    "相机正被其他应用占用，请关闭使用相机的应用后重试。"
                CameraState.ERROR_CAMERA_DISABLED ->
                    "相机已被系统禁用，请检查设备隐私设置或相机权限。"
                CameraState.ERROR_DO_NOT_DISTURB_MODE_ENABLED ->
                    "此设备在勿扰模式下无法打开相机，请关闭勿扰模式后重试。"
                CameraState.ERROR_STREAM_CONFIG ->
                    "此设备暂时无法建立相机预览，请重试。"
                CameraState.ERROR_CAMERA_FATAL_ERROR ->
                    "相机发生错误，请重试；如果问题持续，请重启设备。"
                else -> "相机暂时不可用，请稍后重试。"
            }
            reportError(message)
        }
    }

    fun start() {
        lifecycleOwner.lifecycle.addObserver(lifecycleObserver)
        foreground.set(lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED))
        previewView.previewStreamState.observe(lifecycleOwner, streamObserver)
        try {
            scanner = BarcodeScanning.getClient(
                BarcodeScannerOptions.Builder()
                    .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                    .build(),
            )
            analysis.setAnalyzer(analysisExecutor, ::analyze)
            preview.setSurfaceProvider(previewView.surfaceProvider)
            val providerFuture = ProcessCameraProvider.getInstance(context)
            providerFuture.addListener({
                // The shared provider future must not be cancelled; this owner may be gone already.
                if (disposed.get()) return@addListener
                try {
                    val availableProvider = providerFuture.get()
                    provider = availableProvider
                    val selector = when {
                        availableProvider.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA) ->
                            CameraSelector.DEFAULT_BACK_CAMERA
                        availableProvider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA) ->
                            CameraSelector.DEFAULT_FRONT_CAMERA
                        else -> {
                            reportError("未找到可用相机，请检查设备是否支持相机。")
                            return@addListener
                        }
                    }
                    val camera = availableProvider.bindToLifecycle(
                        lifecycleOwner, selector, preview, analysis,
                    )
                    cameraState = camera.cameraInfo.cameraState.also {
                        it.observe(lifecycleOwner, cameraStateObserver)
                    }
                } catch (_: SecurityException) {
                    reportError("相机权限已失效，请重新授权后重试。")
                } catch (_: Exception) {
                    reportError("无法启动相机，请稍后重试。")
                }
            }, mainExecutor)
        } catch (_: Exception) {
            reportError("无法初始化二维码识别，请重试。")
        }
    }

    @androidx.annotation.OptIn(markerClass = [ExperimentalGetImage::class])
    private fun analyze(imageProxy: ImageProxy) {
        val frameRequest = request.get()
        val frameEpoch = foregroundEpoch.get()
        if (!canDeliver(frameRequest, frameEpoch)) {
            imageProxy.close()
            return
        }
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }

        val task = synchronized(scannerLock) {
            if (frameInFlight || !canDeliver(frameRequest, frameEpoch)) {
                imageProxy.close()
                return
            }
            val activeScanner = scanner
            if (activeScanner == null) {
                imageProxy.close()
                return
            }
            frameInFlight = true
            try {
                activeScanner.process(
                    InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees),
                )
            } catch (_: Exception) {
                frameInFlight = false
                imageProxy.close()
                recognitionFailed.set(true)
                mainExecutor.execute { reportError("二维码识别暂时不可用，请重试。") }
                return
            }
        }

        // Completing on the main executor serializes delivery with lifecycle and UI changes.
        task.addOnCompleteListener(mainExecutor) { completed ->
            try {
                if (!canDeliver(frameRequest, frameEpoch)) return@addOnCompleteListener
                if (completed.isSuccessful) {
                    val value = completed.result.firstNotNullOfOrNull { barcode ->
                        barcode.rawValue?.takeIf(String::isNotEmpty)
                    }
                    if (value != null) {
                        deliveredSession.set(frameRequest.session)
                        onQrCode(value, frameRequest.session)
                    }
                } else {
                    recognitionFailed.set(true)
                    reportError("二维码识别暂时不可用，请重试。")
                }
            } finally {
                // ML Kit still owns mediaImage until its task completes, including after disposal.
                imageProxy.close()
                synchronized(scannerLock) {
                    frameInFlight = false
                    if (disposed.get()) closeScanner()
                }
            }
        }
    }

    private fun canDeliver(frameRequest: ScanRequest, frameEpoch: Int): Boolean {
        val current = request.get()
        return !disposed.get() && !recognitionFailed.get() && foreground.get() &&
            foregroundEpoch.get() == frameEpoch && frameRequest.enabled && current.enabled &&
            current.session == frameRequest.session && deliveredSession.get() != frameRequest.session
    }

    // Called only on the main executor / main lifecycle thread.
    private fun reportError(message: String) {
        if (!disposed.get() && lastError != message) {
            lastError = message
            onError(message)
        }
    }

    fun close() {
        if (!disposed.compareAndSet(false, true)) return
        foreground.set(false)
        foregroundEpoch.incrementAndGet()
        lifecycleOwner.lifecycle.removeObserver(lifecycleObserver)
        previewView.previewStreamState.removeObserver(streamObserver)
        cameraState?.removeObserver(cameraStateObserver)
        analysis.clearAnalyzer()
        // Unbind only use cases created here; other CameraX consumers are left intact.
        provider?.unbind(preview, analysis)
        preview.setSurfaceProvider(null)
        analysisExecutor.shutdown()
        synchronized(scannerLock) {
            if (!frameInFlight) closeScanner()
        }
    }

    private fun closeScanner() {
        scanner?.close()
        scanner = null
    }
}
