package com.a380fly.qrscanner.ui

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.core.net.toUri
import com.a380fly.qrscanner.R
import com.a380fly.qrscanner.permission.rememberCameraPermission
import com.a380fly.qrscanner.state.ScannerViewModel
import kotlinx.coroutines.delay

@Composable
fun ScannerApp(
    viewModel: ScannerViewModel = viewModel(),
    tileScanRequest: String? = null,
) {
    val context = LocalContext.current
    val permission = rememberCameraPermission()
    val tileEntry = rememberQuickSettingsTileEntry()
    var startupCompleted by rememberSaveable { mutableStateOf(tileScanRequest != null) }
    var aboutVisible by rememberSaveable { mutableStateOf(false) }
    var handledTileScanRequest by rememberSaveable { mutableStateOf<String?>(null) }
    val state = viewModel.state

    LaunchedEffect(tileScanRequest) {
        if (tileScanRequest != null && tileScanRequest != handledTileScanRequest) {
            handledTileScanRequest = tileScanRequest
            startupCompleted = true
            aboutVisible = false
            viewModel.clearResult()
        }
    }

    LaunchedEffect(Unit) {
        if (!startupCompleted) {
            delay(1000)
            startupCompleted = true
        }
    }
    LaunchedEffect(startupCompleted, aboutVisible) {
        if (startupCompleted && !aboutVisible && !permission.granted && !permission.requested) {
            permission.request()
        }
    }

    val openGitHub = remember(context) { { openProjectRepository(context) } }
    BackHandler(enabled = aboutVisible) { aboutVisible = false }

    when {
        !startupCompleted -> StartupScreen()
        aboutVisible -> AboutScreen(onBack = { aboutVisible = false }, onGitHub = openGitHub)
        else -> ScannerScreen(
            state = state,
            permission = permission,
            onQrCode = viewModel::onQrCode,
            onClear = viewModel::clearResult,
            onCopy = {
                state.result?.let { value ->
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("扫码结果", value))
                    // Android 13+ already displays the system clipboard confirmation.
                    if (android.os.Build.VERSION.SDK_INT < 33) {
                        Toast.makeText(context, "已复制到剪贴板", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            onAbout = { aboutVisible = true },
            onGitHub = openGitHub,
            onAddQuickSettingsTile = tileEntry.request,
            addingQuickSettingsTile = tileEntry.inProgress,
        )
    }
}

private fun openProjectRepository(context: Context) {
    val address = context.getString(R.string.github_url).trim()
    val uri = address.toUri()
    if (uri.scheme != "https" || uri.host != "github.com" ||
        uri.path.isNullOrBlank() || address.contains("your-username", ignoreCase = true)
    ) {
        Toast.makeText(context, "项目仓库地址尚未发布，敬请期待", Toast.LENGTH_LONG).show()
        return
    }
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE))
    } catch (_: ActivityNotFoundException) {
        Toast.makeText(context, "未找到可打开链接的应用", Toast.LENGTH_LONG).show()
    }
}
