package com.a380fly.qrscanner.state

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ScanStateTest {
    @Test
    fun `first QR result stays visible until cleared`() {
        val state = ScanState().accept("first result", callbackSession = 0)

        assertEquals("first result", state.result)
        assertEquals(0, state.session)
        assertEquals(state, state.accept("first result", callbackSession = 0))
        assertEquals(state, state.accept("another QR code", callbackSession = 0))
    }

    @Test
    fun `clear removes the result and starts the next session`() {
        val state = ScanState().accept("result to clear", callbackSession = 0).clear()

        assertNull(state.result)
        assertEquals(1, state.session)
    }

    @Test
    fun `clearing an empty state still invalidates pending callbacks`() {
        val state = ScanState().clear().clear()

        assertNull(state.result)
        assertEquals(2, state.session)
        assertEquals(state, state.accept("late pending result", callbackSession = 1))
    }

    @Test
    fun `late result from the previous session cannot fill a cleared result`() {
        val cleared = ScanState().accept("old result", callbackSession = 0).clear()
        val afterLateCallback = cleared.accept("late old result", callbackSession = 0)

        assertEquals(cleared, afterLateCallback)
        assertNull(afterLateCallback.result)
    }

    @Test
    fun `current session accepts a result after clear and ignores old callbacks`() {
        val cleared = ScanState().accept("old result", callbackSession = 0).clear()
        val current = cleared.accept("new result", callbackSession = cleared.session)

        assertEquals("new result", current.result)
        assertEquals(1, current.session)
        assertEquals(current, current.accept("stale replacement", callbackSession = 0))
    }

    @Test
    fun `empty text does not lock the scanner`() {
        val afterEmpty = ScanState().accept("", callbackSession = 0)

        assertNull(afterEmpty.result)
        assertEquals("valid result", afterEmpty.accept("valid result", callbackSession = 0).result)
    }

    @Test
    fun `QR text preserves Unicode line breaks and surrounding whitespace`() {
        val original = "  扫码器 😀\nhttps://example.com/路径?值=你好\r\n\t  "
        val state = ScanState().accept(original, callbackSession = 0)

        assertEquals(original, state.result)
    }

    @Test
    fun `whitespace-only QR payload remains a valid unmodified result`() {
        val original = " \t\r\n "
        val state = ScanState().accept(original, callbackSession = 0)

        assertEquals(original, state.result)
        assertEquals(state, state.accept("later result", callbackSession = 0))
    }
}
