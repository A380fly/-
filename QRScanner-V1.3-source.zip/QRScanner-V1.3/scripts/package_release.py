"""Package the already-built APK and sources using the project's actual version."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import zipfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--build-log", type=Path)
    args = parser.parse_args()
    project = Path(__file__).resolve().parent.parent
    properties = {}
    for line in (project / "version.properties").read_text(encoding="utf-8").splitlines():
        if line.strip() and not line.lstrip().startswith("#"):
            key, value = line.split("=", 1)
            properties[key.strip()] = value.strip()
    version = properties["versionName"]
    if not re.fullmatch(r"\d+\.\d", version):
        raise ValueError("versionName must have exactly one decimal place")
    version_code = int(properties["versionCode"])
    apk_dir = project / "app/build/outputs/apk/debug"
    metadata = json.loads((apk_dir / "output-metadata.json").read_text(encoding="utf-8"))
    if len(metadata["elements"]) != 1:
        raise ValueError("Expected one universal Debug APK")
    element = metadata["elements"][0]
    if (element["versionName"], element["versionCode"]) != (version, version_code):
        raise ValueError("APK version is stale; run gradlew.bat :app:assembleDebug first")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    apk_source = apk_dir / element["outputFile"]
    apk_target = args.output_dir / f"扫码器-V{version}-debug.apk"
    archive_target = args.output_dir / f"QRScanner-V{version}-source.zip"
    shutil.copy2(apk_source, apk_target)
    source_items = ["app/src", "app/build.gradle.kts", "gradle", "build.gradle.kts",
                    "settings.gradle.kts", "gradle.properties", "gradlew", "gradlew.bat",
                    ".gitignore", "README.md", "AGENTS.md", "version.properties", "scripts"]
    with zipfile.ZipFile(archive_target, "w", zipfile.ZIP_DEFLATED) as archive:
        for relative in source_items:
            item = project / relative
            for source in sorted(item.rglob("*")) if item.is_dir() else [item]:
                if source.is_file() and "__pycache__" not in source.parts:
                    archive.write(source, Path(f"QRScanner-V{version}") / source.relative_to(project))
    with zipfile.ZipFile(archive_target) as archive:
        if archive.testzip() is not None:
            raise ValueError("Source archive integrity check failed")
    if hashlib.sha256(apk_source.read_bytes()).digest() != hashlib.sha256(apk_target.read_bytes()).digest():
        raise ValueError("APK copy verification failed")
    shutil.copy2(project / "README.md", args.output_dir / f"运行说明-V{version}.md")
    if args.build_log:
        shutil.copy2(args.build_log, args.output_dir / f"构建日志-V{version}.txt")
    print(f"versionName={version}, versionCode={version_code}")
    print(f"APK: {apk_target}")
    print(f"Source: {archive_target}")
    print("APK copy and source ZIP integrity verified.")


if __name__ == "__main__":
    main()
